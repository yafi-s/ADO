from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import os,sys,subprocess,json,shutil,hashlib,gzip
sys.path.insert(0,str(Path.cwd()))
import cv2,numpy as np
from crosswalk.drive import episode
from crosswalk.journey import JourneyScenario
from crosswalk.journey_capture import _load_inputs
from crosswalk.maneuver_scene import score_sequence
from crosswalk.maneuver_trials import route_pose_at
from crosswalk.experiment import write_json,write_trace,save_arrays,fingerprint
from crosswalk.runtime import simulator,producer_info
from crosswalk.showcase import policy_profile,encode_and_check
from crosswalk.world import _raised
from crosswalk.city_progress_bus import body_gap, footprint
from crosswalk.radar_geometry import RADARS
from crosswalk.camera_geometry import CAMERAS
pin="da8d343c0640d0402cb7dee9a8a77980f0302c93";subprocess.run(["git","diff","--quiet",pin,"--","crosswalk","models"],check=True)
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==pin
mode=sys.argv[1];assert mode in ("continuous","later-gap")
p=Path(__file__).parent/"spaced-sectors"/mode;p.mkdir(parents=True)
checkpoint=p/"checkpoint.npz";shutil.copyfile("models/city-maneuvers/candidate.npz",checkpoint)
with ZipFile(p/"source.zip","x",ZIP_DEFLATED) as z:
 for path in sorted(Path("crosswalk").glob("*.py")):z.write(path)
 z.write("models/route-maneuvers/choice.json");z.write(__file__,"spaced_high_sector.py")
model,_,observer,policy=_load_inputs(checkpoint)
req=dict(pin=pin,case=mode,seed=212,start_m=278.,finish_m=735.,recording="Actual High five-camera control rig with full 1280x720 native front optics and normal surround inference; no external chase movie in this qualification.",
 model_sha256=fingerprint(checkpoint),source_sha256=fingerprint(p/"source.zip"),choice_sha256=policy["tactical_sha256"])
write_json(p/"protocol.json",req)
scene=None
def factory(*a,**kw):
 global scene
 scene=JourneyScenario(*a,**kw,barriers=True,population_profile="city-maneuvers",maneuver_case=mode)
 scene.ego.set_transform(_raised(route_pose_at(scene,278.),.35))
 scene.spawn_yaw_deg=scene.spawn_lateral_m=0.
 return scene
class Witness:
 primary_rig_only=True
 def __init__(self,front,ref):
  self.front,self.ref=front,ref;self.count=0;self.original_min_gap=None;self.original_stationary_frames=0;self.ego_min_at_stationary=None
 def append(self,row,obs):
  self.count+=1;frame=row["frame"];m=row["observer_map"];pose=scene.ego.get_transform()
  ref=dict(frame=frame,sim_time=row["sim_time"],progress_m=row["progress_m"],observer_map={k:m[k] for k in ("ego","ego_z","others")},ego_pose=dict(x=pose.location.x,y=pose.location.y,z=pose.location.z,pitch=pose.rotation.pitch,yaw=pose.rotation.yaw,roll=pose.rotation.roll))
  lead=next(e for e in scene.events if e.kind=="lead")
  if lead.actor.get_location().distance(pose.location)<65.:
   v=lead.actor.get_velocity().length()
   gap=float(body_gap(footprint(scene.ego),footprint(lead.actor)))
   self.original_min_gap=gap if self.original_min_gap is None else min(gap,self.original_min_gap)
   if lead.state=="stopped" and v<.25:
    self.original_stationary_frames+=1
    self.ego_min_at_stationary=row["speed_mps"] if self.ego_min_at_stationary is None else min(row["speed_mps"],self.ego_min_at_stationary)
   ref["original_stopped_sedan"]=dict(actor_id=lead.actor.id,speed_mps=round(v,3),ego_mps=row["speed_mps"],body_gap_m=round(gap,3),state=lead.state)
  print(json.dumps(ref,separators=(",",":")),file=self.ref)
  assert obs["front"].shape==(360,640,3) and obs["front_optical"].shape==(720,1280,3)
  assert all(k in obs for k in (*CAMERAS,*RADARS))
  ok,jpg=cv2.imencode(".jpg",obs["front"][:,:,::-1],[cv2.IMWRITE_JPEG_QUALITY,92]);assert ok
  self.front.write(jpg.tobytes())
  if 455.<=row["progress_m"]<=635. and (self.count<2 or self.count%2==0):
   save_arrays(p/"sensor-witness"/f"{frame}.npz",frame=frame,lidar=obs["lidar"],ego_xyz=[pose.location.x,pose.location.y,pose.location.z],
     pitch_yaw_roll=[pose.rotation.pitch,pose.rotation.yaw,pose.rotation.roll],**{k:obs[k] for k in RADARS})
  if self.count%50==1:
   print(self.count,row["progress_m"],row["speed_mps"],row["tactical_pass"].get("maneuver_phase"),
         [(e["kind"],e["handled"]) for e in row["events"] if e["triggered"]],flush=True);self.ref.flush()
os.environ["CROSSWALK_FRONT_HD"]="1"
with simulator(3818,True,"High",map_name="Town03_Opt") as w,policy_profile(policy["camera_profile"]),(p/"front.mjpeg").open("xb") as front,(p/"reference-native.jsonl").open("x") as ref:
 witness=Witness(front,ref)
 summary,trace,*_=episode(w,"journey",212,policy["schema"],model,scene_factory=factory,observation_factory=observer,
  destination="market",crossing_delay=.5,weather="ClearNoon",surround=True,tactical=True,recording=witness,max_steps=2200,change_request=lambda:scene._last_progress>=735.)
 summary.update(producer=producer_info(w),case=mode,model_sha256=req["model_sha256"],source_sha256=req["source_sha256"])
write_trace(p/"trace.jsonl.gz",trace);write_json(p/"summary.json",summary)
save_arrays(p/"observations.npz",frame=[r["frame"] for r in trace],feature_names=policy["control_feature_names"],features=model.observations,requested_mps=model.requested_speed,posted_limit_kmh=model.posted_limits)
with (p/"reference-native.jsonl").open("rb") as a,gzip.open(p/"reference.jsonl.gz","xb") as b:shutil.copyfileobj(a,b)
by={e["kind"]:e for e in summary["events"]};kinds=("signal","roadworks","in-lane-obstruction","slow-traffic","barrier","lead")
sequence=score_sequence(summary["events"],trace);lead=by["lead"]
clear=all(by[k]["handled"] and not by[k]["violation"] for k in kinds)
motion=all(by[k].get("minimum_moving_passing_lane_car_gap_m",-1.)>=1. for k in ("in-lane-obstruction","slow-traffic"))
lead_ok=(lead.get("target_speed_at_exposure_mps",99.)<.25 and abs(lead.get("native_road_s",0.)-274.58)<.10 and witness.original_stationary_frames>0 and witness.original_min_gap is not None and witness.original_min_gap>=.25 and "restarted_s" in lead and "left_route_s" in lead)
ok=bool(sequence["passed"] and clear and motion and lead_ok and summary["progress_m"]>=734.4 and not summary["collision_events"] and not summary["red_light_violations"] and not summary["yield_violations"] and not summary["background_traffic_activity"]["participant_contacts"])
write_json(p/"grade.json",dict(passed=ok,sequence=sequence,target_handled={k:by[k]["handled"] for k in kinds},source_fully_stopped_restarted_exited=lead_ok,original_stopped_observed_frames=witness.original_stationary_frames,ego_minimum_during_original_sedan_stop_mps=witness.ego_min_at_stationary,original_minimum_body_gap_m=witness.original_min_gap,old_and_new_lead_route_station_m=[576.648,lead["station_m"]],moving_passing_lane_gap_passed=motion,first_frame=trace[0]["frame"],last_frame=trace[-1]["frame"]))
print("FINAL",mode,ok,sequence,flush=True)
encode_and_check(p/"front.mjpeg",p/"front.mp4",(640,360),0,len(trace))
