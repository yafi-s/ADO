"""Longitudinal support from observed pavement and swept-body clearance at higher speeds."""
import numpy as np

from . import behavior_v2 as v2
from .city_clearance import BODY
from .policy import _returns, LIDAR_Z, RADAR_X, RADAR_Z


def long_sight(lidar, radar, path, speed):
    """Return pavement extent and first obstruction after removing the measured ground plane."""
    laser, doppler = _returns(lidar), _returns(radar)
    if len(laser)<100 or len(doppler)<20 or len(path)<8:
        return 0.,0.
    x,y,z = laser[:,0],laser[:,1],laser[:,2]+LIDAR_Z
    a,b,c = v2._ground_plane(x,y,z)
    # This clearance head is for level, measured pavement. A changing grade
    # can shorten the valid witness or put a surface above the ground plane.
    if abs(a)>.075 or abs(b)>.085:
        return 0.,0.
    roi=(x>0.) & (x<77.) & (abs(y)<38.)
    x,y,h=x[roi],y[roi],(z-a*x-b*y-c)[roi]
    s,d=v2._project(x,y,path)
    end=float(np.linalg.norm(np.diff(path,axis=0),axis=1).sum())-2.25
    valid=(s>=0.) & (s<min(70.,end-.2))
    ground=valid & (abs(h)<.22)
    # A stationary sign, low cone, person or moving vehicle is a genuine
    # obstruction until outside the swept path and its approach shoulders.
    solid=valid & (h>.20) & (h<3.2)
    # The legacy 36m horizon cannot measure the high-speed extension.
    def first(stations, mask):
        return float(min(stations[mask])) if mask.any() else 75.
    body=first(s,solid & (abs(d)<BODY+.4))
    shoulder=first(s,solid & (abs(d)<4.5))
    velocity,az,alt,depth=doppler.T
    flat=depth*np.cos(alt)
    rx,ry,rz=flat*np.cos(az)+RADAR_X,flat*np.sin(az),depth*np.sin(alt)+RADAR_Z
    st,side=v2._project(rx,ry,path)
    raised=rz-a*rx-b*ry-c
    rv=velocity+speed*np.cos(az)*np.cos(alt)
    targets=(st>=0.) & (st<end-.2) & (rx>0.) & (raised>.18) & (raised<3.2)
    body=min(body,first(st,targets & (abs(side)<BODY+.4)))
    shoulder=min(shoulder,first(st,targets & (abs(side)<4.5)),
                 first(st,targets & (abs(side)<7.0) & (abs(rv)>2.)))
    # Each range section needs positive ground in the lane and on both sides.
    # Beyond 15m, successive rays of a 32-channel spinning sensor land further
    # apart. Limit the gap between actual returns in each strip. A bounded gap
    # moves the horizon only once the next surface has really been observed.
    strips=[]
    for lo,hi in ((-4.8,-1.5),(-1.2,1.2),(1.5,4.8)):
        stations=np.sort(s[ground & (d>lo) & (d<hi)])
        if len(stations)<5:
            return 0.,body
        delta=np.diff(np.r_[0.,stations])
        # Sampling geometry for level pavement at the actual 32-channel
        # vertical spacing. At long range cap allowed inter-ring spacing.
        allowed=np.clip(1.+.024*stations**2/2.3,3.,12.)
        gaps=np.flatnonzero(delta>allowed)
        count=int(gaps[0]) if len(gaps) else len(stations)
        strips.append(float(stations[count-1]) if count else 0.)
    return max(0.,min(*strips,body,shoulder)),body
