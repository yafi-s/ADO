"""Market Loop native traffic and control-rig qualification from a pinned sparse checkout."""
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile
from unittest.mock import patch
from functools import partial
import sys,os,time,math,hashlib,json,gzip,subprocess,shutil
sys.path.insert(0,str(Path.cwd()))
import carla,cv2,numpy as np
from crosswalk import drive,robotaxi
from crosswalk.journey import JourneyScenario
from crosswalk.journey_capture import _load_inputs
from crosswalk.city_progress_bus import body_gap,footprint
from crosswalk.experiment import write_json,write_trace,fingerprint,save_arrays
from crosswalk.maneuver_trials import route_pose_at
from crosswalk.maneuver_scene import score_sequence,_polygon
from crosswalk.runtime import producer_info,simulator
from crosswalk.sensors import Rig
from crosswalk.showcase import policy_profile,encode_and_check
from crosswalk.world import _raised
from crosswalk.radar_geometry import RADARS
from crosswalk.camera_geometry import CAMERAS
pin="727f097d8760248e23431021ace61ff2c48b6d5e"
phase,case=sys.argv[1:3]
assert phase in ("commission","prefix","tail") and case in ("continuous","later-gap")
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==pin
subprocess.run(["git","diff","--quiet",pin,"--","crosswalk","models"],check=True)
p=Path(__file__).parent/"market-loop-native"/(f"{phase}-{case}"+("-"+sys.argv[3] if len(sys.argv)>3 else ""))
p.mkdir(parents=True)
cp=p/"checkpoint.npz";shutil.copyfile("models/city-maneuvers/candidate.npz",cp)
with ZipFile(p/"source.zip","x",ZIP_DEFLATED) as z:
 for path in sorted(Path("crosswalk").glob("*.py")):z.write(path)
 z.write("models/route-maneuvers/choice.json");z.write(__file__,"market_loop_qualify.py")
contract=dict(pin=pin,phase=phase,case=case,seed=212,start_m=0. if phase=="prefix" else 1300.,end_m=715. if phase=="prefix" else 1719.890,
 model_sha256=fingerprint(cp),source_sha256=fingerprint(p/"source.zip"),map="Town03_Opt",weather="ClearNoon",step_s=.1,
 sensor_configuration="Stock five-camera surround body and rig, 1280x720 native front optical image, exact control crop of native 100 m lidar and all five native radar sensors; normal episode policy.",
 omitted="Chase movie and the rider-only YOLOX/SurroundPerception pass. RGB NanoDet, map/route, lamp, LiDAR and radar control paths are unmodified.")
write_json(p/"protocol.json",contract)
def warm(scene):
    scene.ego.set_transform(_raised(route_pose_at(scene,1300.),.35))
    scene.spawn_lateral_m=scene.spawn_yaw_deg=0.
    scene.ego.apply_control(carla.VehicleControl(brake=1.,hand_brake=True))
    for _ in range(8):scene.world.tick()
    origin=scene.ego.get_location()
    last=None
    for step in range(900):
        scene.before_tick();frame=scene.world.tick()
        convoy=[v for v in scene.ambient._cars if v.road==69]
        settled=all(v.previous is not None and v.actor.get_location().distance(v.path[-1])<3. and v.actor.get_velocity().length()<.25 for v in convoy)
        active=scene.maneuver_fixture
        if (step%50==0):
            last=[(v.road,v.lane,round(v.traveled,1),round(v.actor.get_location().distance(v.path[-1]),1),v.departed_lane) for v in convoy]
            print("WARM",step,last,"registered",bool(active.moving),flush=True)
        if any(v.departed_lane for v in convoy):raise RuntimeError(f"Original traffic left native corridor {last}")
        if settled and active.moving and "first_native_arrival_check" in active.lead_event.observed:
            break
    else:raise RuntimeError(f"Unready physical return traffic or missing witnessed spawn {last}")
    pose=scene.ego.get_location()
    error=math.hypot(pose.x-origin.x,pose.y-origin.y)
    if error>.4 or active.clock_start is not None:raise RuntimeError("Test departure drifted during native traffic warm-up")
    record=dict(native_actor_warmup_s=(step+1)*.1,ego_drift_xy_m=error,convoy_paths=[dict(actor_id=v.actor.id,departure_road=69,lane=v.lane,
      traveled_m=round(v.traveled,3),terminal_error_m=round(v.actor.get_location().distance(v.path[-1]),3),
      actual_road=scene._map.get_waypoint(v.actor.get_location()).road_id,actual_lane=scene._map.get_waypoint(v.actor.get_location()).lane_id) for v in convoy],
      arrivals=active.lead_event.observed,participant_contacts=scene.ambient.traffic_activity["participant_contacts"],
      population=scene.ambient.counts)
    write_json(p/"commission.json",record)
    if record["participant_contacts"]:raise RuntimeError("Native warm-up participant contact")
    scene.ego.apply_control(carla.VehicleControl(brake=1.))
    return record
class ControlRig(Rig):
    """Keep actual stock surround calibration while suppressing the separate viewer inference."""
    def __init__(self,*args,**kw):
        kw["surround"]=True;super().__init__(*args,**kw)
    def read(self,frame):
        obs=super().read(frame);scan=obs["lidar"]
        ControlRig.latest_raw_scan=(frame,scan)
        # Identical radius and arithmetic to the surround branch in crosswalk.drive.episode.
        obs["lidar"]=scan[np.einsum("ij,ij->i",scan[:,:3],scan[:,:3])<=60**2]
        return obs
scene=None
def factory(*args,**kw):
    global scene
    scene=JourneyScenario(*args,**kw,barriers=True,population_profile="city-maneuvers",maneuver_case=case)
    try:
        if phase=="tail":warm(scene)
    except BaseException:
        scene.close();raise
    return scene
class Witness:
    primary_rig_only=True
    def __init__(self,front,ref,journal):
        self.front=front;self.ref=ref;self.journal=journal;self.count=0
        self.stationary=0;self.held_gap=999.;self.ego_at_hold=999.
    def append(self,row,obs):
        self.count+=1;pose=scene.ego.get_transform();m=row["observer_map"];frame=row["frame"]
        if obs["front"].shape!=(360,640,3) or obs["front_optical"].shape!=(720,1280,3) or not all(k in obs for k in (*CAMERAS,*RADARS)):
            raise RuntimeError("Native camera/range contract differs")
        if self.count==1:
            reduced=cv2.resize(obs["front_optical"],(640,360),interpolation=cv2.INTER_AREA)
            laser_frame,full_laser=ControlRig.latest_raw_scan
            wanted=np.einsum("ij,ij->i",full_laser[:,:3],full_laser[:,:3])<=60**2
            if frame!=laser_frame or not np.array_equal(full_laser[wanted],obs["lidar"]):raise RuntimeError("Control laser differs from exact native 60 m range mask")
            if not np.array_equal(reduced,obs["front"]):raise RuntimeError("Front control RGB differs from the native High downsample")
            write_json(p/"control-input-contract.json",dict(first_frame=frame,front_control_equals_native_optical_downsample=True,
             controller_laser_equals_native_range_mask=True,first_full_return_count=len(full_laser),first_control_return_count=len(obs["lidar"]),native_front_size=list(obs["front_optical"].shape),control_front_size=list(obs["front"].shape),
             native_view_sizes={name:list(obs[name].shape) for name in CAMERAS},radars=list(RADARS),lidar_radius_m=60.,noncontrol_rider_tracker="omitted"))
        if len(obs["lidar"]) and np.max(np.einsum("ij,ij->i",obs["lidar"][:,:3],obs["lidar"][:,:3]))>3600.0001:
            raise RuntimeError("Normal controller laser horizon was exceeded")
        native=scene._map.get_waypoint(pose.location)
        ref=dict(frame=frame,sim_time=row["sim_time"],progress_m=row["progress_m"],ego_native=[native.road_id,native.lane_id,native.s],
         ego_pose=dict(x=pose.location.x,y=pose.location.y,z=pose.location.z,pitch=pose.rotation.pitch,yaw=pose.rotation.yaw,roll=pose.rotation.roll),
         ego_polygon_xy=footprint(scene.ego).tolist(),observer_map={k:m[k] for k in ("ego","ego_z","others")})
        e=next(e for e in scene.events if e.kind=="lead")
        nearby=[]
        for participant,role in [(e.actor,"lead")]+[(a,role) for a,_,role in scene.maneuver_fixture.spectator_actors()]:
            if participant.is_alive and participant.get_location().distance(pose.location)<75.:
                body=_polygon(participant);gap=float(body_gap(footprint(scene.ego),body))
                wp=scene._map.get_waypoint(participant.get_location());speed=participant.get_velocity().length()
                nearby.append(dict(actor_id=participant.id,role=role,speed_mps=speed,body_gap_m=gap,polygon_xy=body.tolist(),native=[wp.road_id,wp.lane_id,wp.s]))
                if role=="lead":
                    self.held_gap=min(self.held_gap,gap)
                    if e.state=="stopped" and speed<.25:self.stationary+=1;self.ego_at_hold=min(self.ego_at_hold,row["speed_mps"])
        ref["targets"]=nearby
        print(json.dumps(ref,separators=(",",":")),file=self.ref)
        print(json.dumps({k:row.get(k) for k in ("frame","sim_time","progress_m","speed_mps","progress_evidence","tactical_pass","events")},separators=(",",":")),file=self.journal)
        ok,jpg=cv2.imencode(".jpg",obs["front"][:,:,::-1],[cv2.IMWRITE_JPEG_QUALITY,92]);assert ok;self.front.write(jpg.tobytes())
        if self.count%5==0 and (390.<=row["progress_m"]<=565. or row["progress_m"]>=1570.):
            save_arrays(p/"sensor-witness"/f"{frame}.npz",frame=frame,lidar=obs["lidar"],ego_xyz=[pose.location.x,pose.location.y,pose.location.z],
                        pitch_yaw_roll=[pose.rotation.pitch,pose.rotation.yaw,pose.rotation.roll],**{k:obs[k] for k in RADARS})
        if self.count%50==1:
            print("DRIVE",self.count,row["progress_m"],row["speed_mps"],row["tactical_pass"].get("maneuver_phase"),[(e["kind"],e["handled"]) for e in row["events"] if e["triggered"]],flush=True)
            self.ref.flush();self.journal.flush()
os.environ["CROSSWALK_FRONT_HD"]="1"
with simulator(3818,True,"High",map_name="Town03_Opt") as world:
    world.tick()
    if phase=="commission":
        scene=JourneyScenario(world,"journey",212,barriers=True,population_profile="city-maneuvers",maneuver_case=case,destination="market-loop",crossing_delay=.5)
        try:print("COMMISSION OK",warm(scene),flush=True)
        finally:scene.close();world.tick()
        raise SystemExit(0)
    model,_,observer,policy=_load_inputs(cp)
    with policy_profile(policy["camera_profile"]),patch.object(drive,"Rig",ControlRig),patch.object(robotaxi,"BodyKit",partial(robotaxi.BodyKit,surround=True)),(p/"front.mjpeg").open("xb") as front,(p/"reference-native.jsonl").open("x") as ref,(p/"live.jsonl").open("x") as journal:
        witness=Witness(front,ref,journal)
        summary,trace,*_=drive.episode(world,"journey",212,policy["schema"],model,scene_factory=factory,observation_factory=observer,tactical=True,surround=False,recording=witness,
         destination="market-loop",crossing_delay=.5,weather="ClearNoon",max_steps=2300,change_request=(lambda: scene._last_progress>=780. or (scene._last_progress>=715. and next(e for e in scene.events if e.kind=="lead").record()["handled"])) if phase=="prefix" else None)
    summary.update(producer=producer_info(world),case=case,phase=phase,model_sha256=contract["model_sha256"],source_sha256=contract["source_sha256"],sensor_configuration=contract["sensor_configuration"],omitted_viewer_work=contract["omitted"])
write_json(p/"summary.json",summary);write_trace(p/"trace.jsonl.gz",trace)
save_arrays(p/"observations.npz",frame=[r["frame"] for r in trace],feature_names=policy["control_feature_names"],features=model.observations,requested_mps=model.requested_speed,posted_limit_kmh=model.posted_limits)
with (p/"reference-native.jsonl").open("rb") as a,gzip.open(p/"reference.jsonl.gz","xb") as b:shutil.copyfileobj(a,b)
by={e["kind"]:e for e in summary["events"]}; seq=score_sequence(summary["events"],trace)
req=("pedestrian","occluded","signal","roadworks","in-lane-obstruction","barrier","lead") if phase=="prefix" else ("slow-traffic",)
end=contract["end_m"]
safety=(not summary["collision_events"] and not summary["yield_violations"] and not summary["red_light_violations"] and not summary["background_traffic_activity"]["participant_contacts"])
pos=by["in-lane-obstruction" if phase=="prefix" else "slow-traffic"]
moving_safe=pos.get("minimum_moving_passing_lane_car_gap_m",0.)>=1.
extra=(witness.stationary>0 and witness.held_gap>=.25 and abs(by["lead"]["native_road_s"]-237.58)<.1 and "left_route_s" in by["lead"]) if phase=="prefix" else (seq["actual_wait_policy_frames"]>0 and by["slow-traffic"]["source_lane"]==[67,3] and by["slow-traffic"]["passing_lane"]==[67,2])
passed=bool(all(by[k]["handled"] and not by[k]["violation"] for k in req) and summary["progress_m"]>=end-.6 and safety and moving_safe and extra)
write_json(p/"grade.json",dict(passed=passed,phase=phase,case=case,scored_target_status={k:by[k]["handled"] for k in req},minimum_moving_passing_lane_gap_m=pos.get("minimum_moving_passing_lane_car_gap_m"),safety=bool(safety),true_wait_frames=seq["actual_wait_policy_frames"],original_stationary_frames=witness.stationary,ego_minimum_while_original_stopped_mps=witness.ego_at_hold if witness.stationary else None,closest_original_gap_m=witness.held_gap if witness.held_gap<999 else None,first_frame=trace[0]["frame"],last_frame=trace[-1]["frame"],reached_end_m=summary["progress_m"]))
posted=np.asarray(model.posted_limits); speeds=np.asarray([r["speed_mps"] for r in trace])*3.6
terminal=[i for i,r in enumerate(trace) if r["progress_m"]>=1584.]
write_json(p/"posted-speeds.json",dict(posted_limit_changes=[dict(frame=trace[i]["frame"],progress_m=trace[i]["progress_m"],posted_kmh=float(posted[i]))
 for i in range(len(posted)) if i==0 or posted[i]!=posted[i-1]],
 final_boulevard_frames=len(terminal),final_boulevard_peak_kmh=float(max(speeds[terminal])) if terminal else None,
 final_boulevard_median_kmh=float(np.median(speeds[terminal])) if terminal else None))
print("FINAL",phase,case,passed,summary["outcome"],summary["progress_m"],flush=True)
encode_and_check(p/"front.mjpeg",p/"front.mp4",(640,360),0,len(trace))
