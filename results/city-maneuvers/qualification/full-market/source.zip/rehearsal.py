"""Local preflight on the unchanged main episode back end, with compact native population tape."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from functools import partial
import sys,os,json,shutil
sys.path.insert(0,str(Path.cwd()))
from crosswalk.runtime import simulator,producer_info
from crosswalk.experiment import write_json,write_trace,fingerprint,save_arrays
from crosswalk.city_drive import load_driver,LoggedDriver
from crosswalk.drive import episode
from crosswalk.journey import JourneyScenario
from crosswalk.maneuver_scene import score_sequence
from crosswalk.population_score import score_population
from crosswalk.journey_capture import _result
from crosswalk.journey import required_event_kinds
import subprocess
pin="9bd6dafa0348d37e163a3acf8de553f642bebf45"
subprocess.run(["git","diff","--quiet",pin,"--","crosswalk","models"],check=True)
root=Path(__file__).parent/sys.argv[1]
root.mkdir()
write_json(root/"qualification.json",dict(pin=pin, command=sys.argv[1:], port=3718, map="Town03_Opt"))
checkpoint=root/"checkpoint.npz"
shutil.copyfile("models/city-maneuvers/candidate.npz",checkpoint)
with ZipFile(root/"source.zip","x",ZIP_DEFLATED) as z:
 for p in sorted(Path("crosswalk").glob("*.py")):z.write(p)
 z.write(__file__,"rehearsal.py")
 z.write("models/route-maneuvers/choice.json")
policy,names,schema=load_driver(checkpoint)
driver=LoggedDriver(policy)
class Witness:
 primary_rig_only=True
 def __init__(self,stream):
  self.stream=stream
  self.num=0
 def append(self,row,obs):
  src=row["observer_map"]
  x={k:row[k] for k in ("frame","sim_time","progress_m")}
  x["observer_map"]={k:src[k] for k in ("ego","ego_z","others")}
  print(json.dumps(x,separators=(",",":")),file=self.stream)
  self.num+=1
  if self.num%50==1:
   print(self.num, row["progress_m"],row["speed_mps"],row["phase"],[(e["kind"],e["handled"]) for e in row["events"] if e["triggered"]],flush=True)
   self.stream.flush()
scene=partial(JourneyScenario,barriers=True,population_profile="city-maneuvers")
with simulator(3718,True,"High",map_name="Town03_Opt") as world, (root/"reference-native.jsonl").open("x") as stream:
 sm,tr,*_=episode(world,"journey",212,schema,driver,scene_factory=scene,recording=Witness(stream),
                  weather="ClearNoon",tactical=True,destination="market",crossing_delay=.5,max_steps=6500)
 sm["producer"]=producer_info(world)
write_trace(root/"trace.jsonl.gz",tr)
write_json(root/"summary.json",sm)
save_arrays(root/"observations.npz",frame=[r["frame"] for r in tr],features=driver.observations,
            feature_names=names,requested_mps=driver.requested_speed,posted_limit_kmh=driver.posted_limits)
grade=_result(sm,required_event_kinds("Town03_Opt",barriers=True,maneuvers=True))
grade["sequence"]=score_sequence(sm["events"],tr)
grade.update(model_sha256=fingerprint(checkpoint),source_sha256=fingerprint(root/"source.zip"))
write_json(root/"grade.json",grade)
score=score_population(root/"reference-native.jsonl",root/"population-reference.jsonl.gz")
write_json(root/"population-score.json",score)
print("FINAL",sm["outcome"],sm["frames"],grade["failure_reasons"],grade["sequence"],score["radii_m"]["50"],flush=True)
