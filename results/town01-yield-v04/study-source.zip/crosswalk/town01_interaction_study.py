"""Frozen Town01 focused interaction test. Keep a trace and checkpoint for every drive."""
import argparse
import hashlib
import json
from pathlib import Path

from . import experiment as ex, report, runtime, sensors
from .revision_benchmark import read_case, run_case, source_files, writer_lock
from .town01_interaction import BASE, MODEL, ROOT, InteractionModel, digest

SCHEDULE = {
    "known_failure": [(105, "left"), (104, "pedestrian-delayed"), (107, "left"),
                      (2111, "left"), (2112, "left"), (2113, "left")],
    "known_control": [(104, "left"), (103, "pedestrian-delayed"), (104, "turn"), (104, "clear")],
    "fresh_challenge": [(4901, "left"), (4902, "left"), (4901, "pedestrian-delayed"),
                        (4902, "pedestrian-delayed"), (4902, "turn"), (4902, "clear")],
}


def study(output, port):
    output = Path(output)
    sources = source_files("crosswalk.town01_interaction_study:study")
    hashes = {name: digest(path) for name, path in sorted(sources.items())}
    for path in (BASE, MODEL, ROOT/"data/signals/approach-gate.json", ROOT/"vendor/nanodet/object_detection_nanodet_2022nov.onnx"):
        hashes[path.relative_to(ROOT).as_posix()] = digest(path)
    manifest = dict(schedule={group: [list(p) for p in pairs] for group, pairs in SCHEDULE.items()},
                    hashes=hashes, rgb=sensors.render_profile(), map="Town01_Opt", timestep_s=.1)
    version = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    marker = output/"manifest.json"
    with writer_lock(output):
        if marker.exists() and ex.read_json(marker) != manifest:
            raise ValueError("Frozen inputs changed. Use a new study directory.")
        ex.write_json(marker, manifest)
        with runtime.simulator(port=port) as world:
            producer = runtime.producer_info(world)
            if producer != {"server_version":"1.0", "client_version":"1.0", "map":"Town01_Opt"}:
                raise ValueError(f"Wrong producer {producer}")
            rows = []
            for group, pairs in SCHEDULE.items():
                for seed, case in pairs:
                    trial = ex.Trial(seed, case, "interaction-v04", "heldout", group)
                    folder = output/trial.trial_id
                    row = read_case(folder, version, trial)
                    if row is None:
                        print("Starting", trial.trial_id, flush=True)
                        row = run_case(world, trial, folder, InteractionModel.load(), version,
                                       producer, sensors.render_profile())
                    rows.append(dict(group=group, seed=seed, case=case, clean=report.clean(row),
                        outcome=row["outcome"], collisions=row["collision_events"], yields=row["yield_violations"],
                        reds=row["red_light_violations"], route_id=row["route_id"], duration_s=row["duration_s"]))
                    ex.write_json(output/"results.json", rows)
                    print(rows[-1], flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"results/town01-yield-v04")
    parser.add_argument("--port", type=int, default=2992)
    args = parser.parse_args()
    study(args.output, args.port)
