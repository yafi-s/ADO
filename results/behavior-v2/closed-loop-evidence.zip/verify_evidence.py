"""Check a closed-loop evidence ZIP with Python's standard library."""
import argparse
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import zipfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def clean(row):
    return (row["outcome"] == "complete" and row["collision_events"] == 0
            and row["red_light_violations"] == 0 and row["yield_violations"] == 0)


def read_json(archive, member):
    return json.loads(archive.read(member))


def verify(zip_path):
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        checks = dict(line.split("  ", 1)[::-1] for line in archive.read("SHA256SUMS").decode().splitlines())
        require(len(names) == len(set(names)) and set(checks) == set(names) - {"SHA256SUMS"}, "Unexpected ZIP members")
        for name, digest in checks.items():
            require(hashlib.sha256(archive.read(name)).hexdigest() == digest, name)
        manifest = read_json(archive, "manifest.json")
        study_id = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
        historical = read_json(archive, "execution/results/primary.json")
        case_key = lambda r: (r["seed"], r["case_id"])
        setup_fields = ("route_id", "road_ids", "junction_ids", "route_length_m", "destination", "weather",
                        "spawn_lateral_m", "spawn_yaw_deg", "district", "crossing_delay_s", "start_xy",
                        "background_actors", "sensor_configuration", "producer", "render_profile")
        for stage in ("regression", "fresh"):
            arms = {"baseline": {}, "candidate": {}}
            if stage == "regression":
                arms["baseline"] = {case_key(row): row for row in historical}
                require(len(arms["baseline"]) == 100, "Historical cohort count")
            report = read_json(archive, stage + "/report.json")
            frame_count = 0
            for trial in manifest["stages"][stage]:
                seed, case, arm = trial["seed"], trial["case_id"], trial["policy"]
                directory = f"{stage}/{seed}-{case}-{arm}/"
                marker = read_json(archive, directory + "checkpoint.json")
                require(marker["trial"] == trial and marker["study"] == study_id, directory)
                for leaf, digest in marker["sha256"].items():
                    require(checks[directory + leaf] == digest, directory + leaf)
                row = read_json(archive, directory + "summary.json")
                require(case_key(row) == (seed, case) and row["policy"] == arm and row["study_id"] == study_id, directory)
                require(case_key(row) not in arms[arm], "Duplicate case " + directory)
                arms[arm][case_key(row)] = row
                with gzip.open(io.BytesIO(archive.read(directory + "trace.jsonl.gz")), "rt", encoding="utf-8") as stream:
                    frames = [json.loads(line) for line in stream]
                require(bool(frames) and len(frames) == row["frames"], directory + "frame count")
                require(all(r["frame"] == frames[0]["frame"] + i and r["sim_time"] == round(.1*i, 2)
                            and r["seed"] == seed and r["policy"] == arm for i, r in enumerate(frames)), directory + "sequence")
                require(all(frames[-1][frame] == row[summary] for frame, summary in (
                    ("collision_count", "collision_events"), ("red_light_violations", "red_light_violations"),
                    ("yield_violations", "yield_violations"), ("progress_m", "progress_m"))), directory + "terminal state")
                frame_count += len(frames)
            for arm, group in arms.items():
                stats = report["arms"][arm]
                require(stats["drives"] == len(group) and stats["clean"] == sum(map(clean, group.values())), arm)
                require(stats["unique_layouts"] == len({r["route_id"] for r in group.values()}), arm + " layout count")
                require(stats["outcomes"] == Counter(r["outcome"] for r in group.values()), arm + " outcomes")
            paired, mismatched = Counter(), []
            require(arms["baseline"].keys() == arms["candidate"].keys(), "Missing paired cases")
            labels = {(True, True): "both_clean", (True, False): "baseline_only",
                      (False, True): "candidate_only", (False, False): "neither_clean"}
            for key in sorted(arms["baseline"]):
                old, new = (arms[a][key] for a in ("baseline", "candidate"))
                if all(old[f] == new[f] for f in setup_fields):
                    paired[labels[clean(old), clean(new)]] += 1
                else:
                    mismatched.append(list(key))
            require(dict(paired) == report["paired_clean"] and mismatched == report["setup_mismatches"], stage + " pairing")
            print(f"{stage}: verified {len(manifest['stages'][stage])} new drives, {frame_count} frames, "
                  f"{sum(paired.values())} matched pairs")
    print(f"Verified SHA-256 for {len(checks)} payload files. Study {study_id}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    verify(parser.parse_args().archive)
